// ************ Andrew/Oct2004 ************
// really just a list of variables
// used by the ActiveX Help control and the popup method
// All popup text should appear here for easy editing
//
// Modified: 15/06/2005

popFont="Arial,9,,ITALIC"

strPasswordPolicies="Zásady hesiel určujú, ako sa heslo vytvára. Dĺžku, písmená, čísla a špeciálne znaky použité na generovanie hesla je možné jednoducho nastaviť v príslušnom dialógovom okne v menu Spravovať."

strBruce="Autor knihy Aplikovaná kryptografia a ďalších kníh, tvorca algoritmu Blowfish a zakladateľ a CTO spoločnosti Counterpane Internet Security."

strSpecialChars="   `   ~   !   @   #   $   %   ^   &   *   (   )   _   +   -   =   |   }   {   [   ]   <   >   ?   /   \   :   ;   |   "

strMasterPassword="V našej terminológii je hlavné heslo to heslo, ktoré používate na získanie prístupu k databáze Password Safe."

strPopText1="Dummy Placeholder"

strExternalFile="Podporované formáty súborov: Databáza Password Safe verzia 1.x; textové súbory oddelené tabulátormi (.txt). DÔRAZNE sa odporúča, aby ste sa podľa možnosti vyhýbali používaniu textových súborov s citlivými informáciami o hesle a aby ste súbor následne bezpečne vymazali."

strHexDec="Iba nasledovné:\n 0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f"
